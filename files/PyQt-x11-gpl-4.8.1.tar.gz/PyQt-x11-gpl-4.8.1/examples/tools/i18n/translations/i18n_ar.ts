<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>First</source>
        <translation>أول</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>مثال التدويل</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>متماثل</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>اللغة: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>العربية</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>مصمت</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>منظور</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>ثانى</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>ثالث</translation>
    </message>
    <message>
        <source>View</source>
        <translation>مرئى</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>أخرج</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>الملف</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>RTL</translation>
    </message>
</context>
</TS>
